class Clip {
  final String id;
  final String content;
  final String category;

  Clip({
    required this.id,
    required this.content,
    required this.category,
  });

  factory Clip.fromFirestore(Map<String, dynamic> data, String id) {
    return Clip(
      id: id,
      content: data["content"] ?? "",
      category: data["category"] ?? "Others",
    );
  }
}
