import 'package:flutter/material.dart';
import 'package:smartstack_app/features/clips/models/clip.dart';
import 'package:smartstack_app/services/clip_service.dart';

class ClipDetailScreen extends StatefulWidget {
  final Clip clip;

  const ClipDetailScreen({super.key, required this.clip});

  @override
  State<ClipDetailScreen> createState() => _ClipDetailScreenState();
}

class _ClipDetailScreenState extends State<ClipDetailScreen> {
  final ClipService clipService = ClipService();

  late TextEditingController contentController;
  late TextEditingController categoryController;

  @override
  void initState() {
    super.initState();
    contentController = TextEditingController(text: widget.clip.content);
    categoryController = TextEditingController(text: widget.clip.category);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Edit Clip")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: contentController,
              maxLines: 3,
              decoration: const InputDecoration(
                labelText: "Content",
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: categoryController,
              decoration: const InputDecoration(
                labelText: "Category",
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 28),
            ElevatedButton(
              onPressed: () async {
                await clipService.updateClip(
                  widget.clip.id,
                  contentController.text.trim(),
                  categoryController.text.trim(),
                );

                Navigator.pop(context);
              },
              child: const Text("Save"),
            )
          ],
        ),
      ),
    );
  }
}
