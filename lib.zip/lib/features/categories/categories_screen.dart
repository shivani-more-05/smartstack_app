import 'package:flutter/material.dart';
import 'package:smartstack_app/services/clip_service.dart';
import 'package:smartstack_app/features/clips/models/clip.dart';
import 'package:smartstack_app/features/clips/screens/clip_detail_screen.dart';

const Color deepLilac = Color(0xFF8C6EC7);

class CategoriesScreen extends StatelessWidget {
  final String categoryName;

  const CategoriesScreen({super.key, required this.categoryName});

  @override
  Widget build(BuildContext context) {
    final Stream<List<Clip>> stream = categoryName == "All Clips"
        ? clipService.streamAllClips()
        : clipService.streamClipsByCategory(categoryName);

    return Scaffold(
      appBar: AppBar(
        title: Text(categoryName),
        backgroundColor: deepLilac,
      ),
      body: StreamBuilder<List<Clip>>(
        stream: stream,
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final clips = snapshot.data!;

          if (clips.isEmpty) {
            return const Center(
              child: Text(
                "No clips found",
                style: TextStyle(fontSize: 16, color: Colors.black54),
              ),
            );
          }

          return ListView.builder(
            itemCount: clips.length,
            itemBuilder: (context, index) {
              final clip = clips[index];

              return Card(
                margin: const EdgeInsets.all(12),
                child: ListTile(
                  title: Text(clip.content),
                  subtitle: Text(clip.category),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => ClipDetailScreen(clip: clip),
                      ),
                    );
                  },
                  trailing: IconButton(
                    icon: const Icon(Icons.delete, color: Colors.red),
                    onPressed: () {
                      clipService.deleteClip(clip.id);
                    },
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
