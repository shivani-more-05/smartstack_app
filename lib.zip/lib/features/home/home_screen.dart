import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:smartstack_app/services/clip_service.dart';
import 'package:smartstack_app/features/clips/screens/clip_detail_screen.dart';
import 'package:smartstack_app/features/categories/categories_screen.dart';

const Color lavenderMist = Color(0xFFECE6F6);
const Color deepLilac = Color(0xFF8C6EC7);

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String searchQuery = "";

  final List<Map<String, dynamic>> categories = [
    {"name": "Links", "icon": Icons.link},
    {"name": "Notes", "icon": Icons.note},
    {"name": "Quotes", "icon": Icons.format_quote},
    {"name": "Emails", "icon": Icons.email},
    {"name": "Phone Numbers", "icon": Icons.phone},
    {"name": "Code Snippets", "icon": Icons.code},
    {"name": "Others", "icon": Icons.folder_open},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: lavenderMist,
      floatingActionButton: FloatingActionButton(
        backgroundColor: deepLilac,
        child: const Icon(Icons.add, color: Colors.white),
        onPressed: saveFromClipboard,
      ),
      appBar: AppBar(
        title: const Text("SmartStack"),
        backgroundColor: deepLilac,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "Welcome back 👋",
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
                color: deepLilac,
              ),
            ),
            const SizedBox(height: 10),
            const Text(
              "Your saved clips at one place",
              style: TextStyle(fontSize: 16, color: Colors.black54),
            ),

            const SizedBox(height: 20),

            // SEARCH BOX
            TextField(
              decoration: InputDecoration(
                hintText: "Search clips...",
                prefixIcon: const Icon(Icons.search, color: deepLilac),
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: BorderSide.none,
                ),
              ),
              onChanged: (val) => setState(() => searchQuery = val),
            ),

            const SizedBox(height: 25),

            const Text(
              "Categories",
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: deepLilac,
              ),
            ),

            const SizedBox(height: 15),

            // CATEGORY GRID
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: categories.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3,
                crossAxisSpacing: 16,
                mainAxisSpacing: 16,
              ),
              itemBuilder: (context, index) {
                final item = categories[index];
                return InkWell(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) =>
                            CategoriesScreen(categoryName: item["name"]),
                      ),
                    );
                  },
                  child: Container(
                    decoration: BoxDecoration(
                      color: deepLilac.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(item["icon"], color: deepLilac, size: 32),
                        const SizedBox(height: 8),
                        Text(
                          item["name"],
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            color: deepLilac,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),

            const SizedBox(height: 25),

            const Text(
              "Recent Clips",
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: deepLilac,
              ),
            ),
            const SizedBox(height: 15),

            StreamBuilder<List<Map<String, dynamic>>>(
              stream: clipService.getRecentClips(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }

                final clips = snapshot.data!;
                return Column(
                  children: clips.map((clip) {
                    return Card(
                      color: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: ListTile(
                        title: Text(
                          clip["content"],
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                        subtitle: Text(clip["category"]),
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => ClipDetailScreen(
                                data: clip,
                                clipId: clip["id"],
                              ),
                            ),
                          );
                        },
                      ),
                    );
                  }).toList(),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  void saveFromClipboard() async {
    ClipboardData? data = await Clipboard.getData("text/plain");

    if (data == null || data.text == null || data.text!.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Clipboard empty")),
      );
      return;
    }

    final category = clipService.detectCategory(data.text!);

    await clipService.saveClip(data.text!, category);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("Saved to $category")),
    );
  }
}
