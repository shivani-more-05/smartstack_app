import 'package:flutter/material.dart';
import 'package:smartstack_app/services/clip_service.dart';
import 'package:smartstack_app/features/clips/screens/clip_detail_screen.dart';

class CategoriesScreen extends StatelessWidget {
  final String categoryName;

  const CategoriesScreen({
    super.key,
    required this.categoryName,
  });

  @override
  Widget build(BuildContext context) {
    // Stream of Maps (NOT Clip model)
    final Stream<List<Map<String, dynamic>>> stream =
        clipService.getClipsByCategory(categoryName);

    return Scaffold(
      appBar: AppBar(
        title: Text(categoryName),
      ),
      body: StreamBuilder<List<Map<String, dynamic>>>(
        stream: stream,
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final clips = snapshot.data!;
          if (clips.isEmpty) {
            return const Center(
              child: Text(
                "No clips found",
                style: TextStyle(color: Colors.black54, fontSize: 16),
              ),
            );
          }

          return ListView.builder(
            itemCount: clips.length,
            itemBuilder: (context, index) {
              final clip = clips[index];

              return ListTile(
                title: Text(clip["content"]),
                subtitle: Text(clip["category"]),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => ClipDetailScreen(
                        data: clip, // USE MAP
                        clipId: clip["id"], // FIRESTORE ID
                      ),
                    ),
                  );
                },
                trailing: IconButton(
                  icon: const Icon(Icons.delete, color: Colors.red),
                  onPressed: () {
                    clipService.deleteClip(clip["id"]);
                  },
                ),
              );
            },
          );
        },
      ),
    );
  }
}
