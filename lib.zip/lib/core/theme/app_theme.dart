import 'package:flutter/material.dart';

/// ---------- UPDATED APP COLORS ----------
const Color primaryTeal = Color(0xFF4DB6AC); // main accent color
const Color darkGrey = Color(0xFF37474F); // text + icons
const Color lightBackground = Color(0xFFF5F7FA); // background

/// ---------- APP THEME ----------
final ThemeData appTheme = ThemeData(
  scaffoldBackgroundColor: lightBackground,
  primaryColor: primaryTeal,
  colorScheme: const ColorScheme.light(
    primary: primaryTeal,
    secondary: darkGrey,
  ),
  textTheme: const TextTheme(
    headlineMedium: TextStyle(
      fontSize: 22,
      fontWeight: FontWeight.bold,
      color: darkGrey,
    ),
    bodyMedium: TextStyle(
      fontSize: 16,
      color: Colors.black87,
    ),
  ),
  appBarTheme: const AppBarTheme(
    elevation: 0,
    backgroundColor: Colors.white,
    foregroundColor: darkGrey,
  ),
);
