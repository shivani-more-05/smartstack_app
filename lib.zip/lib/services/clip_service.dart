import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class ClipService {
  final _firestore = FirebaseFirestore.instance;
  final _auth = FirebaseAuth.instance;

  String get userId => _auth.currentUser!.uid;

  // SAVE CLIP
  Future<void> saveClip(String content, String category) async {
    await _firestore.collection('users').doc(userId).collection('clips').add({
      'content': content,
      'category': category,
      'timestamp': FieldValue.serverTimestamp(),
    });
  }

  // DETECT CATEGORY (FULL WORKING)
  String detectCategory(String text) {
    final t = text.trim();

    if (t.startsWith("http") || t.contains(".com")) return "Links";
    if (t.contains("@")) return "Emails";
    if (t.replaceAll(RegExp(r'[^0-9]'), '').length >= 7) return "Phone Numbers";
    if (t.contains(";") || t.contains("{") || t.contains("=>")) {
      return "Code Snippets";
    }
    if (t.length <= 40) return "Notes";
    return "Others";
  }

  // STREAM ALL
  Stream<List<Map<String, dynamic>>> getRecentClips() {
    return _firestore
        .collection("users")
        .doc(userId)
        .collection("clips")
        .orderBy("timestamp", descending: true)
        .snapshots()
        .map(
            (snap) => snap.docs.map((d) => {...d.data(), "id": d.id}).toList());
  }

  // STREAM CATEGORY
  Stream<List<Map<String, dynamic>>> getClipsByCategory(String category) {
    return _firestore
        .collection('users')
        .doc(userId)
        .collection('clips')
        .where("category", isEqualTo: category)
        .orderBy("timestamp", descending: true)
        .snapshots()
        .map(
            (snap) => snap.docs.map((d) => {...d.data(), "id": d.id}).toList());
  }

  // DELETE
  Future<void> deleteClip(String id) async {
    await _firestore
        .collection('users')
        .doc(userId)
        .collection('clips')
        .doc(id)
        .delete();
  }

  // UPDATE CLIP
  Future<void> updateClip(
      String clipId, String newContent, String newCategory) async {
    await _firestore
        .collection('users')
        .doc(userId)
        .collection('clips')
        .doc(clipId)
        .update({
      'content': newContent,
      'category': newCategory,
    });
  }
}

final clipService = ClipService();
